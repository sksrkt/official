<?php
ini_set('display_errors',0);
ini_set('log_errors',1);


$fdata = $_POST;
$b = $fdata['base'];
$var='';
$counter = $fdata['counter'];
$series = "";

$numberRepeatTimes = $fdata['numberRepeatTimes'];

$genrateno = array();

for($i=0; $i<=$counter; $i++){
   $var =$b.rand(100000,999999);
    $var_ar = str_split($var);
    $valueCount = array_count_values ($var_ar);
   
  foreach ($valueCount as $val){
      
      if ($val >= $numberRepeatTimes && !in_array($var, $genrateno)) {
            $caught = $var;
            $genrateno[] = $caught;
            $series = $series.$caught."\n";
      }     
    }    
    $i = count($genrateno);
}
$content = $series;
$my_file = 'series.txt';
clearstatcache();
$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
if (isset($handle)) {
    echo "Yes, file genrated";
}
$data = $content;
fwrite($handle, $data);
fclose($handle);
?>