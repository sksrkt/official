<?php
error_reporting( E_ALL );

$base = array(9811);

$lev1Repeat = 8;
$lev2Repeat = 7;
$lev3Repeat = 6;

$var='';
$counter = 999999;
$series1 = "";
$series2 = "";
$series3 = "";

$genrateno1 = array();
$genrateno2 = array();
$genrateno3 = array();

//$numberRepeatTimes = 0;
foreach ($base as $value) {
    for($i=0; $i<=$counter; $i++){
        $endNo  = str_pad($i, 6, '0', STR_PAD_LEFT);
        $var = $value.$endNo;
        
        // $var = $b.sprintf('%06d', $i);
        $var_ar = str_split($var);
        $valueCount = array_count_values ($var_ar);
        // print_r($valueCount);
        foreach ($valueCount as $val){
            if ($val >= $lev1Repeat && !in_array($var, $genrateno1)) {
                $caught = $var;
                $genrateno1[] = $caught;
                $series1 = $series1.$caught."\n";
            }
            
            else if ($val >= $lev2Repeat && !in_array($var, $genrateno2)) {
                $caught = $var;
                $genrateno2[] = $caught;
                $series2 = $series2.$caught."\n";
            }
            
            else if ($val >= $lev3Repeat && !in_array($var, $genrateno3)) {
                $caught = $var;
                $genrateno3[] = $caught;
                $series3 = $series3.$caught."\n";
            }
        }
        //$i = count($genrateno);
    }
    if($series1 != ''){
        $content = $series1;
        // echo $content;
        $my_file = 'tier1.txt';
        clearstatcache();
        $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
        if (isset($handle)) {
            echo "<br /> Number's in Teir 1 :- ". sizeof($genrateno1);
        }
        $data = $content;
        fwrite($handle, $data);
        fclose($handle);
    }
    
    if($series2 != ''){
        
        $content = $series2;
        // echo $content;
        $my_file = 'tier2.txt';
        clearstatcache();
        $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
        if (isset($handle)) {
            echo "<br /> Number's in Teir 2 :- ".sizeof($genrateno2);
        }
        $data = $content;
        fwrite($handle, $data);
        fclose($handle);
    }
    
    if($series3 != ''){
        
        $content = $series3;
        // echo $content;
        $my_file = 'tier3.txt';
        clearstatcache();
        $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
        if (isset($handle)) {
            echo "<br />Number's in Teir 3 :- ".sizeof($genrateno3);
        }
        $data = $content;
        fwrite($handle, $data);
        fclose($handle);
    }
    /* $content = $series;
     // echo $content;
     $my_file = 'seriestoshow.txt';
     clearstatcache();
     $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
     if (isset($handle)) {
     echo "Hey! Your, file genrated";
     }
     $data = $content;
     fwrite($handle, $data);
     fclose($handle); */
}

if (isset($handle)) {
    echo "<br />Hey! Your, files genrated<br />";
}

if(isset($_GET['link']))
{
    $var_1 = $_GET['link'];
    
    $dir = "/var/www/html/";
    $file = $dir . $var_1;
    
    if (file_exists($file))
    {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename='.basename($file));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        ob_clean();
        flush();
        readfile($file);
        exit;
    }
}

echo"<br />".'<a href="tier1.txt?link=tier1.txt">View Tier 1</a>';
echo"<br />".'<a href="tier2.txt?link=tier2.txt">View Tier 2</a>';
echo"<br />".'<a href="tier3.txt?link=tier3.txt">View Tier 3</a>';













?>