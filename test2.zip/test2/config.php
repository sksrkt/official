<?php
$host = "localhost";
$userName = "debian-sys-maint";
$password = "8HeW7FS3GyGblWga";
$dbName = "emora";
// Create database connection
$conn = new mysqli($host, $userName, $password, $dbName);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
?>