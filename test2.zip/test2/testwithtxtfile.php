<?php
error_reporting( E_ALL );

function read_and_delete_first_line($filename) {
    $file = file($filename);
    $output = $file[0];
    unset($file[0]);
    file_put_contents($filename, $file);
    return $output;
}


$seriesMob = fopen("series.txt", "r") or die("Unable to open file!");
if ($seriesMob) {
   $file = explode("\n", fread($seriesMob, filesize("series.txt")));
   
}
$baseData = $file;

$lev1Repeat = 8;
$lev2Repeat = 7;
$lev3Repeat = 6;


$counter = 999999;

$var='';
$loopCounter = 0;
//$numberRepeatTimes = 0;

foreach ($baseData as $value) {    
    echo "<br />----------------------<br />";
    echo $value;
    echo "<br />----------------------<br />";
    
    $series1 = "";
    $series2 = "";
    $series3 = "";
    $series4 = "";
    
    $genrateno1 = array();
    $genrateno2 = array();
    $genrateno3 = array();
    $genrateno4 = array();
    
        for($i=0; $i<=$counter; $i++){
            $endNo  = str_pad($i, 6, '0', STR_PAD_LEFT);
            $var = $value.$endNo;
            // $var = $b.sprintf('%06d', $i);
            $var_ar = str_split($var);
            $valueCount = array_count_values($var_ar);
            // print_r($valueCount);
            foreach ($valueCount as $val){
                if ($val >= $lev1Repeat && !in_array($var, $genrateno1)) {
                    $caught = $var;
                    $genrateno1[] = $caught;
                    $series1 = $series1.$caught."\n";
                    
                }
                
                else if ($val >= $lev2Repeat && !in_array($var, $genrateno2)) {
                    $caught = $var;
                    $genrateno2[] = $caught;
                    $series2 = $series2.$caught."\n";
                    
                }
                
                else if ($val >= $lev3Repeat && !in_array($var, $genrateno3)) {
                    $caught = $var;
                    $genrateno3[] = $caught;
                    $series3 = $series3.$caught."\n";
                    
                }
            }
            
            $v = '';
            $repeatCounter = 1;
            foreach ($var_ar as $valueafter) {
                // echo $valueafter;
                if ($valueafter == $v) {
                    //echo "<br />RepeatVal ".$valueafter;
                    $repeatCounter++;
                }
                else{
                    //echo "<br />NewValue ".$v = $valueafter;
                    $v = $valueafter;
                    $repeatCounter = 1;
                }
                //echo "<br />RepeatCount ".$repeatCounter;
                if ($repeatCounter == 5) {
                    //echo "<br />line:47 ".$valueafter;
                    //echo "<br />---------";
                    if (!in_array($var, $genrateno4)) {
                        $caught = $var;
                        $genrateno4[] = $var;
                        $series4 = $series4.$caught."\n";
                        $repeatCounter = 1;
                        
                    }
                    $v = "";
                }
            }
        }
   
   if($series1 != ''){        
        $content = $series1;
        // echo $content;
        $my_file = '/var/www/html/test2/existingNumberWise/tier1/'.$value.'.txt';
        clearstatcache();
        $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
        if (isset($handle)) {
            echo "<br /> $value Teir 1 :- ". count($genrateno1);
        }
        $data = $content;
        fwrite($handle, $data);
        fclose($handle);
        
    }
    unset($series1);
    
    if($series2 != ''){
        
        $content = $series2;
        // echo $content;
        $my_file = '/var/www/html/test2/existingNumberWise/tier2/'.$value.'.txt';
        clearstatcache();
        $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
        if (isset($handle)) {
            echo "<br /> $value Teir 2 :- ".count($genrateno2);
        }
        $data = $content;
        fwrite($handle, $data);
        fclose($handle);
    }
    unset($series2);
    
    if($series3 != ''){
        
        $content = $series3;
        // echo $content;
        $my_file = '/var/www/html/test2/existingNumberWise/tier3/'.$value.'.txt';
        clearstatcache();
        $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
        if (isset($handle)) {
            echo "<br />$value Teir 3 :- ".count($genrateno3);
        }
        $data = $content;
        fwrite($handle, $data);
        fclose($handle);
        
    }
    unset($series3);
    
     if($series4 != ''){
        
        $content = $series4;
        // echo $content;
        $my_file = '/var/www/html/test2/consicutiveNumberWise/tier1/'.$value.'.txt';
        clearstatcache();
        $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
        if (isset($handle)) {
            echo "<br />$value Teir 4 :- ".count($genrateno4);
        }
        $data = $content;
        fwrite($handle, $data);
        fclose($handle);
        
    }
    unset($series4);
    
    $filename = 'series.txt';
    read_and_delete_first_line($filename);
    
    if (++$loopCounter == 10) break;
 }

/* if (isset($handle)) {
    echo "<br />Hey! Your, files genrated<br />";
}

if(isset($_GET['link']))
{
    $var_1 = $_GET['link'];
    
    $dir = "/var/www/html/test2";
    $file = $dir . $var_1;
    
    if (file_exists($file))
    {
        header('Content-Description: File Transfer');
        header('Content-Type: application/oct$countforlineet-stream');
        header('Content-Disposition: attachment; filename='.basename($file));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        ob_clean();
        flush();
        readfile($file);
        exit;
    }
} 

echo"<br />".'<a href="tier1.txt?link=tier1.txt">View Tier 1</a>';
echo"<br />".'<a href="tier2.txt?link=tier2.txt">View Tier 2</a>';
echo"<br />".'<a href="tier3.txt?link=tier3.txt">View Tier 3</a>';
echo"<br />".'<a href="tier4.txt?link=tier3.txt">View Tier 4</a>';
 */



?>