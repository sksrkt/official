<?php
error_reporting( E_ALL );
require("config.php");

$dbSeries = array();
$sql = "SELECT data FROM Teir1;";
$sql .= "SELECT data FROM Teir2;";
$sql .= "SELECT data FROM Teir3;";
// Execute multi query
if (mysqli_multi_query($conn,$sql))
{
    do
    {
        // Store first result set
        if ($result=mysqli_store_result($conn)) {
            // Fetch one and one row
            while ($row=mysqli_fetch_row($result))
            {
               $row[$row];
               foreach ($row as $base_no=>$series_no){
                   echo "<pre>";
                   print_r($base_no);
                   echo "<pre 2>";
                   print_r($series_no);
               }
            }
            // Free result set
            mysqli_free_result($result);
        }
    }
    while (mysqli_next_result($conn));
}
/* $index = 0;
while($row = mysqli_fetch_assoc($query)){ // loop to store the data in an associative array.
   echo $row;
}
echo "<pre>";
print_r($dbSeries); */
die;


$base = array(9000,9001,9002,9003,9004,9005,9006,9007,9008,9009);

$lev1Repeat = 8;
$lev2Repeat = 7;
$lev3Repeat = 6;

$fdata = $_POST;

if( isset($fdata) ) {
    $numBase = $fdata['base'];
    $counter = $fdata['counter'];
}
$var='';
$counter = 100;
$series = "";

//$numberRepeatTimes = 0;
foreach ($base as $value) {
    $numBase = $value;
    $genrateno = array();
  
    for($i=0; $i<=$counter; $i++){
        $endNo  = str_pad($i, 6, '0', STR_PAD_LEFT);
        $var = $numBase.$endNo;
        //$var =$numBase.sprintf('%06d', $i);
        
        $var_ar = str_split($var);
        $valueCount = array_count_values ($var_ar);
        /* echo "<pre>".print_r($valueCount);
        die; */
        foreach ($valueCount as $val){
            
            if ($val >= $lev1Repeat) {
                $caught = $var;
                $genrateno[] = $caught;
                $series = $series.$caught."\n";
                $content = $series;
                $my_file = 'serieslevel1.txt';
                clearstatcache();
                $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
                $data = $content;
                fwrite($handle, $data);
                fclose($handle);
                $dataMob= explode(" ",$series);
                
                foreach ($dataMob as $item_id=>$item_no)
                {
                    // connect to mysql database
                    $query = mysqli_query($conn, "INSERT INTO Teir1 (id, data, level) VALUES ('$item_id', '$item_no', '1')");
                   
                }
                
                unset($series);
                
            }elseif ($val == $lev2Repeat) {
                $caught = $var;
                $genrateno[] = $caught;
                $series = $series.$caught."\n";
                $content = $series;
                $my_file = 'serieslevel2.txt';
                clearstatcache();
                $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
                $data = $content;
                fwrite($handle, $data);
                fclose($handle);
                $dataMob= explode(" ",$series);
                
                foreach ($dataMob as $item_id=>$item_no)
                {
                    // connect to mysql database
                    $query = mysqli_query($conn, "INSERT INTO Teir2 (id, data, level) VALUES ('$item_id', '$item_no', '2')");
                    
                }
                unset($series);
                
            }elseif ($val == $lev3Repeat){
                $caught = $var;
                $genrateno[] = $caught;
                $series = $series.$caught."\n";
                $content = $series;
                $my_file = 'serieslevel3.txt';
                clearstatcache();
                $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
                $data = $content;
                fwrite($handle, $data);
                fclose($handle);
                $dataMob= explode(" ",$series);
                
                foreach ($dataMob as $item_id=>$item_no)
                {
                    // connect to mysql database
                    $query = mysqli_query($conn, "INSERT INTO Teir3 (id, data, level) VALUES ('$item_id', '$item_no', '3')");
                    
                }
                unset($series);
            }
            
        }
        $i = count($genrateno);
    }
    
   
}

if (isset($handle)) {
    echo "Yes, files genrated";
}

?>