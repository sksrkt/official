<?php
ini_set('display_errors',0);
ini_set('log_errors',1);
require("config.php");


$base = array(9000,9001,9002,9003,9004,9005,9006,9007,9008,9009);

$lev1Repeat = 8;
$lev2Repeat = 7;
$lev3Repeat = 6;

$fdata = $_POST;

if( isset($fdata) ) {
    $numBase = $fdata['base'];
    $counter = $fdata['counter'];
}
$var='';
$counter = 100;
$series = "";

//$numberRepeatTimes = 0;
foreach ($base as $value) {
    $numBase = $value;
    $genrateno = array();
  
    for($i=0; $i<=$counter; $i++){
        $var =$numBase.sprintf('%06d', $i);
        
        $var_ar = str_split($var);
        $valueCount = array_count_values ($var_ar);
        /* echo "<pre>".print_r($valueCount);
        die; */
        foreach ($valueCount as $val){
            
            if ($val >= $lev1Repeat) {
                $caught = $var;
                $genrateno[] = $caught;
                $series = $series.$caught."\n";
                $content = $series;
                $my_file = 'serieslevel1.txt';
                clearstatcache();
                $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
                $data = $content;
                fwrite($handle, $data);
                fclose($handle);
                $dataMob= explode(" ",$series);
                
                foreach ($dataMob as $item_id=>$item_no)
                {
                    // connect to mysql database
                    $query = mysqli_query($conn, "INSERT INTO series (id, mobseries, level) VALUES ('$item_id', '$item_no', 'serieslevel1')");
                    
                }
                
                unset($series);
                
            }elseif ($val == $lev2Repeat) {
                $caught = $var;
                $genrateno[] = $caught;
                $series = $series.$caught."\n";
                $content = $series;
                $my_file = 'serieslevel2.txt';
                clearstatcache();
                $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
                $data = $content;
                fwrite($handle, $data);
                fclose($handle);
                $dataMob= explode(" ",$series);
                
                foreach ($dataMob as $item_id=>$item_no)
                {
                    // connect to mysql database
                    $query = mysqli_query($conn, "INSERT INTO series (id, mobseries, level) VALUES ('$item_id', '$item_no', 'serieslevel2')");
                    
                }
                unset($series);
                
            }elseif ($val == $lev3Repeat){
                $caught = $var;
                $genrateno[] = $caught;
                $series = $series.$caught."\n";
                $content = $series;
                $my_file = 'serieslevel3.txt';
                clearstatcache();
                $handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
                $data = $content;
                fwrite($handle, $data);
                fclose($handle);
                $dataMob= explode(" ",$series);
                
                foreach ($dataMob as $item_id=>$item_no)
                {
                    // connect to mysql database
                    $query = mysqli_query($conn, "INSERT INTO series (id, mobseries, level) VALUES ('$item_id', '$item_no', 'serieslevel3')");
                    
                }
                unset($series);
            }
            
        }
        $i = count($genrateno);
    }
    
   
}

if (isset($handle)) {
    echo "Yes, files genrated";
}

?>